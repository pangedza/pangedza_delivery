abstract class FirestoreServiceInterface {
  Future<void> saveOrder(Map<String, dynamic> order);
}
