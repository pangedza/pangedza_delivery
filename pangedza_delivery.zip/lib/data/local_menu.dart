const List<Map<String, dynamic>> localMenu = [
  {
    'id': '1',
    'name': 'Лапша удон',
    'price': 250,
    'imageUrl': 'assets/images/placeholder.png',
    'description': 'Вкусная лапша удон.'
  },
  {
    'id': '2',
    'name': 'Суп рамэн',
    'price': 300,
    'imageUrl': 'assets/images/placeholder.png',
    'description': 'Сытный суп рамэн.'
  },
];
